<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Persons;
use App\Address;
use DB;

class LeftJoinController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $address = DB::table('persons')
                      ->leftJoin('addresses', 'persons.address_id', '=', 'addresses.id')
                      ->get();
        return response()->json(['status' => 'success', 'data'=>$address]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
      $address = DB::table('persons')->join('addresses', function($join){
          $join->on('persons.address_id', '=', 'addresses.id')
               ->where('addresses.id','=',$id);
      });
      if($address){
        return response()->json(['status' => 'success', 'data'=>$address]);
      }

      return response()->json(['status'=>'error', 'message' =>'Data not found'],404);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
