<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <table>
    @foreach($address as $adds)
      <tr>
        <td>$adds->id</td>
        <td>$adds->nama</td>
        <td>$adds->address_id</td>
        <td>$adds->jenis_kelamin</td>
        <td>$adds->provinsi</td>
        <td>$adds->kabupaten</td>
        <td>$adds->kodepos</td>
      </tr>
    @endforeach
  </table>
  </body>
</html>
